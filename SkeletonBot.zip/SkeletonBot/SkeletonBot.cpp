#include "SkeletonBot.h"
#include <avr/interrupt.h>
#include <Arduino.h>

SkeletonBot *robotObj = 0;

SkeletonBot::SkeletonBot()
{
	//DO NOT CHANGE THESE PIN ASSIGNMENTS
	//These pins are used for the ArduMoto motor controller
	
	//DO NOT CHANGE THE FOLLOWING VARIABLES
	//These variable are used in the operation of the speed controller
	currLeft = 0;    //Used to calculate change delta ticks on left wheel
	prevLeft = 0;    //Used to calculate change delta ticks on left wheel
	currRight = 0;    //Used to calculate change delta ticks on right wheel
	prevRight = 0;    //Used to calculate change delta ticks on right wheel
	encCntLeft = 0;    //Actual measured amount of ticks on left wheel
	encCntRight = 0;   //Actual measured amount of ticks on right wheel
	encIn = 0;        //Variable used to hold the combination of prev and current encoder values
	error_l = 0.0;
	error_r = 0.0;
	e_old = 0.0;
	e_old2 = 0.0;
	e_old_r = 0.0;
	e_old2_r = 0.0;
	ticks_l = 0.0;
	ticks_r = 0.0;
	ticks_desired_l = 0.0;
	ticks_desired_r = 0.0;
	l_mot = 0.0;    //left motor reference speed
	l_control = 0.0;
	r_mot = 0.0;    //right motor reference speed
	r_control = 0.0;
	error_dist = 0.0;
	error_dist_old = 0.0;
	error_mot = 0.0;

	//Gain parameters for the speed controller PID controller
	Kp = 0.01;      // Proportional gain for PID controller
	Ki = 0.01;
	Kd = 0.01;
	//Gain parameters for the speed control between the two motors, helping the robot travel in a straight line
	Kp_speed = 0.01;
	Ki_speed = 0;
	
	setupMotorControl();
	robotObj = this;
}
void SkeletonBot::velocityControl(float v1, float w1)
{
	ticks_l = encCntLeft * PID_dc;    //Calculates the ticks per second for left wheel
    ticks_r = encCntRight * PID_dc;  //Calcualtes the ticks per second for the right wheel
    
    ticks_desired_l = (v1 - (wheelbase*w1)/2) * (left_ticks_per_rev / (2*pi*left_wheel_radius));
    ticks_desired_r = (v1 + (wheelbase*w1)/2) * (right_ticks_per_rev / (2*pi*right_wheel_radius));
    
    error_l = (ticks_desired_l - ticks_l);
    error_r = (ticks_desired_r - ticks_r);
    
    //Left motor PID Controller
    l_mot = Kp * (error_l - e_old) + Ki*(error_l + e_old)/2 + Kd*(error_l-2*e_old+e_old2); 
    //Right motor PID Controller
    r_mot = Kp * (error_r - e_old_r) + Ki*(error_r + e_old_r)/2 + Kd*(error_r-2*e_old_r+e_old2_r);    
    //Distance travelled between wheels PID controller
    error_dist = ticks_l - ticks_r + w1;
    error_mot = Kp_speed * (error_dist - error_dist_old) + Ki_speed * (error_dist + error_dist_old)/2;
    //Control signals for left and right motor
    l_control += l_mot - error_mot;   
    r_control += r_mot + error_mot; 
    
    //Clamps control signals to accepted values
    if (l_control > 250) l_control = 250;
    if (l_control < -250) l_control = -250;
  
    if (r_control > 250) r_control = 250;
    if (r_control < -250) r_control = -250;    
    
    //Sends control signals to pwm outputs for the motor control
    //If control signal is negative then the motor is reversed    
    //The ABS() of the control signal is used in order to get rid of a negative control value
    digitalWrite(right_motor_direction,right_fwd);    
    if (r_control < 0)     digitalWrite(right_motor_direction,right_rev);
    analogWrite(right_motor_pwm,abs(r_control));
    
    digitalWrite(left_motor_direction,left_fwd);            
    if (l_control < 0)     digitalWrite(left_motor_direction,left_rev);
    analogWrite(left_motor_pwm,abs(l_control));

    encCntLeft = 0;
    e_old2 = e_old;
    e_old = error_l;
    
    encCntRight = 0;
    e_old2_r = e_old_r;
    e_old_r = error_r; 
  
	error_dist_old = error_dist;  
}
int SkeletonBot::getTicks(ENCODER encoder)
{
	switch(encoder)
	{
		case LEFT:
			return encCntLeft;
		case RIGHT:
			return encCntRight;
	}
}

void SkeletonBot::readencoder()
{
	//Use this section if using quad input encoders  
	currLeft = B00110000 & PIND;    //Mask for data from PD4 and PD5 (left wheel encoder)
	currRight = B11000000 & PIND;    //Mask for inputs PD7 and PD6 (right wheel encoder)

	currLeft = currLeft >> 4;
	prevLeft = prevLeft << 2;  
	encIn = currLeft | prevLeft;
	encCntLeft += encoderArray[encIn];
	prevLeft = currLeft;

	currRight = currRight >> 6;
	prevRight = prevRight << 2;
	encIn = currRight | prevRight;
	encCntRight += encoderArray[encIn];
	prevRight = currRight;
}
void SkeletonBot::setupMotorControl()
{
	pinMode(right_motor_pwm, OUTPUT);  //Set control pins to be outputs
	pinMode(left_motor_pwm, OUTPUT);
	pinMode(right_motor_direction, OUTPUT);
	pinMode(left_motor_direction, OUTPUT);
	digitalWrite(right_motor_pwm,LOW);
	digitalWrite(left_motor_pwm,LOW);
	digitalWrite(right_motor_direction,right_fwd);
	digitalWrite(left_motor_direction,left_fwd);        
	analogWrite(right_motor_pwm, 0);    
	analogWrite(left_motor_pwm, 0);    

	//Change default PWM frequency to 30Hz
	TCCR2B = (TCCR2B & 0xF8) | 7;

	PCICR |= (1<<PCIE2);  //Enable interupts in PORTD
	PCMSK2 |= (1<<PCINT23);  //enable int on PD7
	PCMSK2 |= (1<<PCINT22);  //enable int on PD6
	PCMSK2 |= (1<<PCINT21);  //enable int on PD5
	PCMSK2 |= (1<<PCINT20);  // enable int on PD4
	MCUCR=(1<<ISC01)|(1<<ISC00);

	pinMode(chn_l_a,INPUT);
	digitalWrite(chn_l_a,HIGH);
	pinMode(chn_l_b,INPUT);
	digitalWrite(chn_l_b,HIGH);  
	pinMode(chn_r_a,INPUT);
	digitalWrite(chn_r_a,HIGH);  
	pinMode(chn_r_b,INPUT);  
	digitalWrite(chn_r_b,HIGH);
}
ISR(PCINT2_vect)
{
  robotObj->readencoder();
}