
#ifndef Skeleton_h
#define Skeleton_h

#include "Arduino.h"

const int right_motor_pwm = 3;  //PWM control for motor on output A
const int left_motor_pwm = 11;  //PWM control for motor on output B
const int right_motor_direction = 12;
const int left_motor_direction = 13;
//The following pins are used for the encoder inputs
const int chn_l_a = 4;  //Left wheel encoder channel A
const int chn_l_b = 5;  //Left wheel encoder channel B
const int chn_r_a = 7;  //Right wheel encoder channel A
const int chn_r_b = 6;  //Right wheel encoder channel B

//DO NOT CHANGE THESE ASSIGNMENTS
const int encoderArray[]={0,1,-1,0,-1,0,0,1,1,0,0,-1,0,-1,1,0};
const float pi = 3.142;
//ONLY CHANGE THIS UNDER SPECIAL CIRCUMSTANCES
//Constants for timing loop updating PID and control values
const int delta_t = 99;    //time used by PID controller to update control data in milli-seconds
const float PID_dc = 1000 / (delta_t + 1);    //Calcualte how many times this loop fires per second ie converts delta_t to Hz
//Constants for the robot's physical parameters
const int left_ticks_per_rev = 3592; //2256; //1632;  //Wheel encoder ticks per revolution for left wheel
const int right_ticks_per_rev = 3592; //2256; //1632;  //Wheel encoder ticks per revolution for right wheel
const float wheelbase = 173.0;      //Wheelbase of chassis in milli-meters
const float left_wheel_radius = 35.0;  //Wheel radii in milli-meters
const float right_wheel_radius = 35.0;  //Wheel radii in milli-meters
const float left_wheel_circ = 2*pi*left_wheel_radius;
const float right_wheel_circ = 2*pi*right_wheel_radius;
const float left_seg_lin_distance = left_wheel_circ / left_ticks_per_rev;
//Constants controlling the individual wheel rotation direction
const boolean left_fwd = 1;      //If left motor is not rotating the right way change this between 1 and 0 to determine direction
const boolean right_fwd = 1;      //If right motor is not rotating the right way change this between 1 and 0 to determine direction
const boolean left_rev = !left_fwd;
const boolean right_rev = !right_fwd;
enum ENCODER {LEFT, RIGHT};

class SkeletonBot
{
	private:
		unsigned long int old_time;
		unsigned long int time;
		int currLeft;    //Used to calculate change delta ticks on left wheel
		int prevLeft;    //Used to calculate change delta ticks on left wheel
		int currRight;    //Used to calculate change delta ticks on right wheel
		int prevRight;    //Used to calculate change delta ticks on right wheel
		int encCntLeft;    //Actual measured amount of ticks on left wheel
		int encCntRight;   //Actual measured amount of ticks on right wheel
		int encIn;        //Variable used to hold the combination of prev and current encoder values
		float error_l;
		float error_r;
		float e_old;
		float e_old2;
		float e_old_r;
		float e_old2_r;
		float ticks_l;
		float ticks_r;
		float ticks_desired_l;
		float ticks_desired_r;
		float l_mot;    //left motor reference speed
		float l_control;
		float r_mot;    //right motor reference speed
		float r_control;
		float error_dist;
		float error_dist_old;
		float error_mot;
		
		//Gain parameters for the speed controller PID controller
		float Kp;      // Proportional gain for PID controller
		float Ki;
		float Kd;
		//Gain parameters for the speed control between the two motors, helping the robot travel in a straight line
		float Kp_speed;
		float Ki_speed;
		
		void setupMotorControl();
		
	public:
		SkeletonBot();
		void velocityControl(float, float);
		int getTicks(ENCODER);
		void readencoder();
};

#endif